using System;
using System.Collections.Generic;
using System.Text;

namespace eProcurement_SAP
{
    public class Class1
    {
    }
}
