using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Data.SqlClient;
using System.Data;

using eProcurement_DAL;

namespace eProcurement_BLL.UserManagement
{
    public class UserController
    {

        MainController mainController = null;

        public UserController(MainController mainController) 
        {
            this.mainController = mainController;
        }

        public Collection<User> GetUsers()
        {
            return mainController.GetDAOCreator().CreateUserDAO().RetrieveAll(); //UserDAO.RetrieveAll();
        }

        public Collection<User> GetUsers(string userid)
        {
            string whereClause = string.Empty;
            whereClause = "([USERID]<>'" + userid + "' AND [PROFTYP]<>'System')";

            return mainController.GetDAOCreator().CreateUserDAO().RetrieveByQuery(whereClause, "[USERID]"); //UserDAO.RetrieveAll(userid, "[USERID]");
        }

        public Collection<User> GetUsers(string userid, string supplierID, string profType)
        {
            string whereClause = string.Empty;
            
            switch (profType)
            {
                case ProfileType.Supplier:
                    whereClause = "(USERID<>'" + userid + "' AND RTRIM(LTRIM(LIFNR))='" + supplierID.Trim() + "' AND USRROLE<>'Administrator')";
                    break;
                case ProfileType.Buyer:
                    whereClause = "(USERID<>'" + userid + "' AND PROFTYP='" + ProfileType.Buyer + "' AND USRROLE<>'Administrator')"; //(RTRIM(LTRIM(LIFNR))='' OR LIFNR IS NULL)
                    break;
            }

            return mainController.GetDAOCreator().CreateUserDAO().RetrieveByQuery(whereClause, "[USERID]");
        }

        public User GetUser(string userId)
        {
            if (userId.Length > 0)
                return mainController.GetDAOCreator().CreateUserDAO().RetrieveByKey(userId); // UserDAO.RetrieveByKey(userId);

            return null;
        }

        public DataTable GetSuppliers()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("SupplierID");
            dt.Columns.Add("SupplierIDName");

            Collection<Supplier> suplist = mainController.GetDAOCreator().CreateSupplierDAO().RetrieveAll();

            foreach (Supplier s in suplist){
                DataRow dr = dt.NewRow();
                dr["SupplierID"] = s.SupplierID.Trim();
                dr["SupplierIDName"] = "[" + s.SupplierID.Trim() + "] " + s.SupplierName;
                dt.Rows.Add(dr);
            }

            return dt;
        }

        public void InsertUser(User u)
        {
            try
            {
                mainController.GetDAOCreator().CreateUserDAO().Insert(u);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UpdateUser(User u)
        {
            try
            {
                mainController.GetDAOCreator().CreateUserDAO().Update(u);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UpdateUserStatus(string userId, string status, string updatedBy)
        {
            try{
                User u = mainController.GetDAOCreator().CreateUserDAO().RetrieveByKey(userId);

                u.UserStatus = status;
                u.UpdatedBy = updatedBy;
                u.UpdatedDate = Convert.ToInt64(DateTime.Now.ToString("yyyy") + DateTime.Now.ToString("MM") + DateTime.Now.ToString("dd"));
                mainController.GetDAOCreator().CreateUserDAO().Update(u);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UpdateUserPassword(string userId, string pswd, string updatedBy)
        {
            try
            {
                User u = mainController.GetDAOCreator().CreateUserDAO().RetrieveByKey(userId);

                u.UserPassword = pswd;
                u.UpdatedBy = updatedBy;
                u.UpdatedDate = Convert.ToInt64(DateTime.Now.ToString("yyyy") + DateTime.Now.ToString("MM") + DateTime.Now.ToString("dd"));

                mainController.GetDAOCreator().CreateUserDAO().Update(u);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Collection<string> GetBuyerEmailAddrs(string purchaseGroup)
        {
            try
            {
                Collection<string> mailList = new Collection<string>();

                string whereClause = " EKGRP='" + Utility.EscapeSQL(purchaseGroup) + "' ";
                Collection<PurchaseGroup> grps = mainController.GetDAOCreator().CreatePurchaseGroupDAO().RetrieveByQuery(whereClause);
                
                whereClause="";
                foreach (PurchaseGroup grp in grps)
                {
                    if (whereClause == "")
                    {
                        whereClause += "(";
                    }
                    else
                    {
                        whereClause += " or ";
                    }
                    whereClause += "USERID='" + Utility.EscapeSQL(grp.UserId.Trim()) + "'";
                }
                if (whereClause != "")
                    whereClause += ")";
                else
                    whereClause = " 1=2 ";

                Collection<User> users = mainController.GetDAOCreator().CreateUserDAO().RetrieveByQuery(whereClause);
                foreach (User user in users) 
                {
                    mailList.Add(user.UserEmail); 
                }

                return mailList;
            }
            catch (Exception ex)
            {
                Utility.ExceptionLog(ex);
                throw (ex);
            }
        }
    }
}
